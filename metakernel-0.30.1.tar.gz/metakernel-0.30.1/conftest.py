import os
os.environ['JUPYTER_PLATFORM_DIRS'] = '1'