<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>main</name>
    <message>
        <location filename="../qml/main.qml" line="13"/>
        <source>2048 Game</source>
        <translation>2048游戏</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="24"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="26"/>
        <location filename="../qml/main.qml" line="276"/>
        <source>New Game</source>
        <translation>新游戏</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="31"/>
        <source>Exit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="38"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="40"/>
        <source>Labeling</source>
        <translation>标签系统</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="42"/>
        <source>2048</source>
        <translation>2048</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="54"/>
        <source>Degree</source>
        <translation>学位</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="66"/>
        <source>Military Rank</source>
        <translation>军衔</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="78"/>
        <source>PRC</source>
        <translation>天朝</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="91"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <source>English</source>
        <translation type="vanished">英语</translation>
    </message>
    <message>
        <source>Simplified Chinese</source>
        <translation type="vanished">简体中文</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation type="vanished">俄语</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="133"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="135"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="139"/>
        <source>About Qt</source>
        <translation>关于Qt</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="197"/>
        <source>SCORE</source>
        <translation>得分</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="197"/>
        <source>BEST</source>
        <translation>最高分</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="257"/>
        <source>Join the numbers and get to the &lt;b&gt;2048 tile&lt;/b&gt;!</source>
        <translation>把相同的数字相加，得到&lt;b&gt;2048&lt;/b&gt;！</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="314"/>
        <source>Language Setting Hint</source>
        <translation>语言设置提示</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="315"/>
        <source>Please restart the program to make the language setting take effect.</source>
        <translation>为了让语言设置生效，请重启程序。</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="321"/>
        <source>About 2048-Qt</source>
        <translation>关于2048-Qt</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="328"/>
        <source>Game Over</source>
        <translation>游戏结束</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="329"/>
        <source>Game Over!</source>
        <translation>游戏结束！</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="339"/>
        <source>You Win</source>
        <translation>你赢了</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="340"/>
        <source>You win! Continue playing?</source>
        <translation>你赢了！要继续玩吗？</translation>
    </message>
</context>
</TS>
