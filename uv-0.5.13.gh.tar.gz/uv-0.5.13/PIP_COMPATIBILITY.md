This reference document has moved to the
[documentation website](https://docs.astral.sh/uv/pip/compatibility/).
