Schema
======

.. autoclass:: marshmallow.schema.Schema
    :inherited-members:
    :autosummary:

.. autoclass:: marshmallow.schema.SchemaOpts
