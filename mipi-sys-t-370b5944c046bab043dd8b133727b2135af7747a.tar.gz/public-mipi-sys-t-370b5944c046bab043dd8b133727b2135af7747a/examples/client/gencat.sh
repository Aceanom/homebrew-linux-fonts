perl ../../collateral/generator/syst_cgen.pl -c collateral_config.xml
