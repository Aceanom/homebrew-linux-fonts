# :stopdoc:
class IO
  module generic_readable
  end
  module generic_writable
  end
end
# :startdoc:
