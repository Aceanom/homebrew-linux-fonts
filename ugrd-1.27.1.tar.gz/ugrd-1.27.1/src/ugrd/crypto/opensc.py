def check_card(self):
    return "opensc-tool --list-readers"
