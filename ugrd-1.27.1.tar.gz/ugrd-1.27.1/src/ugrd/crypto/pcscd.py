def start_pcscd(self) -> str:
    """Start the pc/sc daemon"""
    return "pcscd"
