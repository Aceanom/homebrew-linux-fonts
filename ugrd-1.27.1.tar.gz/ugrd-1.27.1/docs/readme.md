# Installation

[installation](installation.md)

# Configuration

[configuration](configuration.md)

[bootloader configuration](bootloader_config.md)

# Usage

[usage](usage.md)

[runtime usage](runtime_usage.md)

# Dev manual

[dev_manual](dev_manual.md)

