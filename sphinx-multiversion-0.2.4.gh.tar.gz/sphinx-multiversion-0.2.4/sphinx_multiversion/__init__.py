# -*- coding: utf-8 -*-
from .sphinx import setup
from .main import main

__version__ = "0.2.4"

__all__ = [
    "setup",
    "main",
]
