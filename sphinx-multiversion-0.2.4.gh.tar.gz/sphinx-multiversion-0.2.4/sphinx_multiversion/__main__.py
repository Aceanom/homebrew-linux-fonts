#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
from .main import main

sys.exit(main())
