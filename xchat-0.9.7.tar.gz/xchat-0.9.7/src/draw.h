/* draw.h */

#ifndef draw_h
#define draw_h

#include <gtk/gtk.h>


struct dccdraw
{
   GtkWidget *window;
   GtkWidget *drawing_area;
   GdkPixmap *pixmap;
};

void dcc_close_draw_window(struct DCC *dcc);
void dcc_open_draw_window(struct DCC *dcc);
void dcc_read_draw(struct DCC *dcc, gint sok);
void dcc_draw(struct session *sess, char *nick);


#endif
