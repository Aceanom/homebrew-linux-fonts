Client specific buffers for ZNC
===============================

The client buffer module maintains client specific buffers for
identified clients. Detailed instructions are available on [the
module's page on the ZNC wiki](http://wiki.znc.in/Clientbuffer).

This module was originally written by
[@jpnurmi](https://github.com/jpnurmi), but as [the original
repository](https://github.com/jpnurmi/znc-clientbuffer) is no longer
maintained, this fork is a continuation of his work.
