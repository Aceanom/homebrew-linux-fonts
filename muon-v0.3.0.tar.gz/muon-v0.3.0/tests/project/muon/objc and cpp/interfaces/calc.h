// SPDX-FileCopyrightText: Stone Tickle <lattis@mochiro.moe>
// SPDX-License-Identifier: GPL-3.0-only

#import <Foundation/Foundation.h>

@interface Calc : NSObject
- (int) add: (int) x to: (int) y;
@end
