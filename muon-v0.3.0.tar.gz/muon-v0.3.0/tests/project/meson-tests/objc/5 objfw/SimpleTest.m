#import <ObjFW/ObjFW.h>
#import <ObjFWTest/ObjFWTest.h>

@interface SimpleTest: OTTestCase
@end

@implementation SimpleTest
- (void)testMeson {
}
@end
