#include<stdio.h>

int main(void) {
    printf("This is test #3.\n");
    return 0;
}
