#include<stdio.h>

int main(void) {
    printf("This is test #1.\n");
    return 0;
}
