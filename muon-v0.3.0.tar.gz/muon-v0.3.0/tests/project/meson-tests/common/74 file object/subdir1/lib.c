int func(void) {
    return 1;
}
