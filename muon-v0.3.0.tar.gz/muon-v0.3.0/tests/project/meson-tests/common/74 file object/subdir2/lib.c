int func(void) {
    return 2;
}
