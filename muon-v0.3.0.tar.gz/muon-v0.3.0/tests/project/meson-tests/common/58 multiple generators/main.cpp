#include"source1.h"
#include"source2.h"

int main(void) {
    return func1() + func2();
}
