#!/usr/bin/env python3

import os
import sys

key = sys.argv[1]
expected = sys.argv[2] if len(sys.argv) > 2 else None

if os.environ.get(key) == expected:
    sys.exit(0)

sys.exit(f'Expected {expected!r}, was {os.environ.get(key)!r}')
