int funca(void) { return 0; }
