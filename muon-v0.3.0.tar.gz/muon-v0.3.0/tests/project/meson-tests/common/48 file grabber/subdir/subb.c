int funcb(void) { return 0; }
