int funcc(void) { return 0; }
