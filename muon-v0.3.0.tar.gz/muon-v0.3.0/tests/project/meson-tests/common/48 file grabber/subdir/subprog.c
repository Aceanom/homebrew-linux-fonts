int funca(void);
int funcb(void);
int funcc(void);

int main(void) {
    return funca() + funcb() + funcc();
}
