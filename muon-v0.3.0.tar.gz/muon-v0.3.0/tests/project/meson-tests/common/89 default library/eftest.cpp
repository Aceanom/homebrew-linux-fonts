#include"ef.h"

#include<iostream>

int main(int, char **) {
    Ef var;
    if(var.get_x() == 99) {
        std::cout << "All is fine.\n";
        return 0;
    } else {
        std::cout << "Something went wrong.\n";
        return 1;
    }
}
