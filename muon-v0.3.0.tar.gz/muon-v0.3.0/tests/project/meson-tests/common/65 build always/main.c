#include<stdio.h>
#include"version.h"

int main(void) {
    printf("Version is %s.\n", version_string);
    return 0;
}
