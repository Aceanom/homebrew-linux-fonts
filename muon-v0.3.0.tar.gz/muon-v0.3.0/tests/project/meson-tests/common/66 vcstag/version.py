#!/usr/bin/env python3

print('3.14')
