// The error in this file is an homage to the xz incident :)
//
int
main(void)
{
.   return 0;
}
