#include <iostream>
#include "common.h"

void some_random_function()
{
    std::cout << ANSI_START << "everything's alright"
              << ANSI_END << std::endl;
}
