#include <iostream>
#include "common.h"

struct X86Board: Board {
    const char *target();
    void say_hello();
};

const char *X86Board::target()
{
    return THE_TARGET;
}

void X86Board::say_hello()
{
    std::cout << ANSI_START << "I am a 1996 PC"
              << ANSI_END << std::endl;
}

void initialize_target()
{
    std::cout << ANSI_START << "ready, set, go"
              << ANSI_END << std::endl;
}

static X86Board pc;
