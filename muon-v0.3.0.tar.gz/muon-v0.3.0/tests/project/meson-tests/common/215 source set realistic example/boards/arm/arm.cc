#include "arm.h"

const char *ARMBoard::target()
{
    return THE_TARGET;
}

void ARMBoard::some_arm_thing()
{
}
