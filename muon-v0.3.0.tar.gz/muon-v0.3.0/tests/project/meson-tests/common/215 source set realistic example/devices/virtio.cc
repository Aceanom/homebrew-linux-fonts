#include <iostream>
#include "common.h"
#include "virtio.h"

void VirtioDevice::some_virtio_thing() {
}
