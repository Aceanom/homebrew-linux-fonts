#ifndef VIRTIO_H
#define VIRTIO_H 1

#include "common.h"

struct VirtioDevice: Device {
    void some_virtio_thing();
};

#endif
