#include <iostream>

void some_random_function()
{
    std::cout << ANSI_START << "huh?"
              << ANSI_END << std::endl;
}
