#pragma once

void proj1_func1(void);
void proj1_func2(void);
void proj1_func3(void);
