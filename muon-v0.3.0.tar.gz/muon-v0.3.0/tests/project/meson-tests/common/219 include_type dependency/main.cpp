#include <iostream>
#include <boost/graph/filtered_graph.hpp>

using namespace std;

int main(void) {
  return 0;
}
