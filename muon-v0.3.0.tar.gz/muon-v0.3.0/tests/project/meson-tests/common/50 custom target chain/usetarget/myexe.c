#include<stdio.h>

int main(void) {
    printf("I am myexe.\n");
    return 0;
}
