int func(void);

int main(void) {
    return func();
}
