int func(void);

int main(void) {
    return func() == 1 ? 0 : 1;
}
