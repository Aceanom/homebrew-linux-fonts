#ifdef _MSC_VER
__declspec(dllexport)
#endif
const char*
tachyon_phaser_command (void)
{
    return "shoot";
}
