from limited import hello

def test_hello():
    assert hello() == "hello world"

test_hello()
