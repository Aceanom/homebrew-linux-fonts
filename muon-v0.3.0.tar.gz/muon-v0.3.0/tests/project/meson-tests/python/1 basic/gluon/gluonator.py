def gluoninate():
    return 42
