#!/usr/bin/env python3

from storer import Storer

s = Storer()

if s.get_value() != 0:
    raise SystemExit('Initial value incorrect.')

s.set_value(42)

if s.get_value() != 42:
    raise SystemExit('Setting value failed.')

try:
    s.set_value('not a number')
    raise SystemExit('Using wrong argument type did not fail.')
except TypeError:
    pass
