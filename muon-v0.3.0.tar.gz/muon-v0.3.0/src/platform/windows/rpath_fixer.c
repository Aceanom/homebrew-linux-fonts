/*
 * SPDX-FileCopyrightText: Stone Tickle <lattis@mochiro.moe>
 * SPDX-FileCopyrightText: Vincent Torri <vtorri@outlook.fr>
 * SPDX-License-Identifier: GPL-3.0-only
 */

#include "compat.h"

#include "platform/rpath_fixer.h"

bool
fix_rpaths(const char *elf_path, const char *build_root)
{
	return true;
}
