/*
 * SPDX-FileCopyrightText: Stone Tickle <lattis@mochiro.moe>
 * SPDX-License-Identifier: GPL-3.0-only
 */

#ifndef MUON_EMBEDDED_H
#define MUON_EMBEDDED_H
const char *embedded_get(const char *name);
#endif
