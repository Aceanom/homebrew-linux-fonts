# frozen_string_literal: true

module LLHttp
  VERSION = "0.5.0"

  # [public] LLHttp's current version.
  #
  def self.version
    VERSION
  end
end
