# frozen_string_literal: true

module LLHttp
  # [public] LLHttp's standard error object.
  #
  class Error < StandardError
  end
end
