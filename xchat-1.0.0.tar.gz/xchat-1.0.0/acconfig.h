#undef ENABLE_NLS
#undef HAVE_CATGETS
#undef HAVE_GETTEXT
#undef HAVE_LC_MESSAGES
#undef HAVE_STPCPY
#undef USE_GNOME
#undef USE_PERL
#undef USE_PLUGIN
#undef USE_IMLIB
#undef USE_PANEL
#undef SOCKS
#undef VERSION
#undef PACKAGE

