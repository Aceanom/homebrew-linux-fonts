struct serverentry
{
   int port;
   char channel[202];
   char server[132];
   char password[86];
   char comment[100];
};

struct defaultserv
{
   char *channel;
   char *server;
   char *comment;
   int port;
};
