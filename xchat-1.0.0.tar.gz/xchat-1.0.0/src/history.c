/* X-Chat
 * Copyright (C) 1998 Peter Zelezny.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
 */

#include <string.h>
#include <stdlib.h>
#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>
#include "userlist.h"
#include "xchat.h"
#include "menu.h"
#ifdef USE_GNOME
#include <zvt/zvtterm.h>
#endif

extern GSList *sess_list;
extern GSList *fkey_list;
extern GSList *replace_list;
extern GSList *command_list;
extern void PrintText (struct session *sess, char *text);
extern struct commands cmds[1];
extern GtkWidget *main_book;
extern GtkWidget *main_window;
extern struct xchatprefs prefs;


#define STATE_SHIFT     GDK_SHIFT_MASK
#define	STATE_ALT	GDK_MOD1_MASK
#define STATE_CTRL	GDK_CONTROL_MASK

void
replace_handle (GtkWidget * t)
{
   char *text = gtk_entry_get_text (GTK_ENTRY (t)),
       *postfix_pnt;
   struct popup *pop;
   GSList *list = replace_list;
   char word[140];
   char postfix[140];
   char outbuf[4096];
   int c, len, xlen;

   len = strlen (text);
   for (c = len - 1; c > 0; c--)
   {
      if (text[c] == ' ')
         break;
   }
   if (text[c] == ' ')
      c++;
   xlen = c;
   if (len - c >= (sizeof (word) - 12))
      return;
   memcpy (word, &text[c], len - c);
   word[len - c] = 0;
   len = strlen (word);
   if (word[0] == '\'' && word[len] == '\'')
      return;
   postfix_pnt = NULL;
   for (c = 0; c < len; c++)
   {
      if (word[c] == '\'')
      {
         postfix_pnt = &word[c + 1];
         word[c] = 0;
         break;
      }
   }

   if (postfix_pnt != NULL)
   {
      if (strlen (postfix_pnt) > sizeof (postfix) - 12)
         return;
      strcpy (postfix, postfix_pnt);
   }
   while (list)
   {
      pop = (struct popup *) list->data;
      if (strcmp (pop->name, word) == 0)
      {
         memcpy (outbuf, text, xlen);
         outbuf[xlen] = 0;
         if (postfix_pnt == NULL)
            snprintf (word, sizeof (word), "%s", pop->cmd);
         else
            snprintf (word, sizeof (word), "%s%s", pop->cmd, postfix);
         strcat (outbuf, word);
         gtk_entry_set_text (GTK_ENTRY (t), outbuf);
         return;
      }
      list = list->next;
   }
}

struct session *
find_session_from_inputgad (GtkWidget * w)
{
   GSList *list = sess_list;
   struct session *sess;

   /* First find the session from the widget */
   while (list)
   {
      sess = (struct session *) list->data;
      if (sess->inputgad == w)
         break;
      list = list->next;
   }
   if (!list)
   {
      /*Erm, we didn't find ANY valid session, HELP! */
      return NULL;
   }
   return sess;
}

int
text_is_more_than_just_nick (char *tx)
{
   int c, len = strlen (tx);

   for (c = 0; c < len; c++)
   {
      if (tx[c] == ' ' || tx[c] == ':' || tx[c] == '.' || tx[c] == '?')
         return 1;
   }
   return 0;
}

int
nick_comp_get_nick (char *tx, char *n)
{
   int c, len = strlen (tx);

   for (c = 0; c < len; c++)
   {
      if (tx[c] == ':')
      {
         n[c] = 0;
         return 0;
      }
      if (tx[c] == ' ' || tx[c] == '.' || tx[c] == 0)
         return -1;
      n[c] = tx[c];
   }
   return -1;
}

void
nick_comp_chng (GtkWidget * t, int updown)
{
   struct session *sess;
   struct user *user, *last = NULL;
   char *text, nick[64];
   int len, slen;

   sess = find_session_from_inputgad (t);
   if (sess == NULL)
      return;
   text = gtk_entry_get_text (GTK_ENTRY (t));
   if (nick_comp_get_nick (text, nick) == -1)
      return;
   user = sess->userlist;
   len = strlen (nick);

   while (user)
   {
      slen = strlen (user->user);
      if (len != slen)
      {
         last = user;
         user = user->next;
         continue;
      }
      if (strncasecmp (user->user, nick, len) == 0)
      {
         if (updown == 0)
         {
            if (user->next == NULL)
               return;
            user->weight--;
            user->next->weight++;
            snprintf (nick, sizeof (nick), "%s: ", user->next->user);
         } else
         {
            if (last == NULL)
               return;
            user->weight--;
            last->weight++;
            snprintf (nick, sizeof (nick), "%s: ", last->user);
         }
         gtk_entry_set_text (GTK_ENTRY (t), nick);
         return;
      }
      last = user;
      user = user->next;
   }
}

void
tab_comp_find_common (char *a, char *b)
{
   int c;
   int alen = strlen (a), blen = strlen (b),
       len;

   if (blen > alen)
      len = alen;
   else
      len = blen;
   for (c = 0; c < len; c++)
   {
      if (a[c] != b[c])
      {
         a[c] = 0;
         return;
      }
   }
   a[c] = 0;
}

void
tab_comp_cmd (GtkWidget * t)
{
   char *text = gtk_entry_get_text (GTK_ENTRY (t)),
       *last = NULL, *cmd, *postfix = NULL;
   GSList *list = command_list;
   struct popup *pop;
   int len, i, slen;
   struct session *sess;
   char buf[2048];
   char lcmd[2048];

   sess = find_session_from_inputgad (t);

   text++;
   len = strlen (text);
   if (len == 0)
      return;
   for (i = 0; i < len; i++)
   {
      if (text[i] == ' ')
      {
         postfix = &text[i + 1];
         text[i] = 0;
         len = strlen (text);
         break;
      }
   }

   while (list)
   {
      pop = (struct popup *) list->data;
      slen = strlen (pop->name);
      if (len > slen)
      {
         list = list->next;
         continue;
      }
      if (strncasecmp (pop->name, text, len) == 0)
      {
         if (last == NULL)
         {
            last = pop->name;
            snprintf (lcmd, sizeof (lcmd), "%s", last);
         } else if (last > (char *) 1)
         {
            PrintText (sess, last);
            PrintText (sess, "\t");
            PrintText (sess, pop->name);
            PrintText (sess, "\t");
            last = (void *) 1;
            tab_comp_find_common (lcmd, pop->name);
         } else if (last == (void *) 1)
         {
            PrintText (sess, pop->name);
            PrintText (sess, "\t");
            tab_comp_find_common (lcmd, pop->name);
         }
      }
      list = list->next;
   }

   i = 0;
   while (cmds[i].name != NULL)
   {
      cmd = cmds[i].name;
      slen = strlen (cmd);
      if (len > slen)
      {
         i++;
         continue;
      }
      if (strncasecmp (cmd, text, len) == 0)
      {
         if (last == NULL)
         {
            last = cmd;
            snprintf (lcmd, sizeof (lcmd), "%s", last);
         } else if (last > (char *) 1)
         {
            PrintText (sess, last);
            PrintText (sess, "\t");
            PrintText (sess, cmd);
            PrintText (sess, "\t");
            last = (void *) 1;
            tab_comp_find_common (lcmd, cmd);
         } else if (last == (void *) 1)
         {
            PrintText (sess, cmd);
            PrintText (sess, "\t");
            tab_comp_find_common (lcmd, cmd);
         }
      }
      i++;
   }

   if (last == NULL)
      return;
   if (last == (void *) 1)
      PrintText (sess, "\n");

   if (last > (char *) 1)
   {
      if (strlen (last) > (sizeof (buf) - 1))
         return;
      if (postfix == NULL)
         snprintf (buf, sizeof (buf), "/%s ", last);
      else
         snprintf (buf, sizeof (buf), "/%s %s", last, postfix);
      gtk_entry_set_text (GTK_ENTRY (t), buf);
      return;
   } else if (strlen (lcmd) > (sizeof (buf) - 1))
      return;
   if (postfix == NULL)
      snprintf (buf, sizeof (buf), "/%s", lcmd);
   else
      snprintf (buf, sizeof (buf), "/%s %s", lcmd, postfix);
   gtk_entry_set_text (GTK_ENTRY (t), buf);
}

int
tab_nick_comp (GtkWidget * t)
{
   struct session *sess;
   struct user *user, *best = NULL;
   char *text = gtk_entry_get_text (GTK_ENTRY (t));
   int len, slen, highest = -10000;
   char buf[64];

   if (text[0] == '/')
   {
      tab_comp_cmd (t);
      return 0;
   }
   sess = find_session_from_inputgad (t);
   if (sess->is_dialog)
      return 0;
   if (sess == NULL)
      return 0;

   if (text_is_more_than_just_nick (text))
   {
      return -1;
   }
   user = sess->userlist;
   len = strlen (text);

   if (text[0] == 0)
      return -1;
   while (user)
   {
      slen = strlen (user->user);
      if (len > slen)
      {
         user = user->next;
         continue;
      }
      if (strncasecmp (user->user, text, len) == 0)
      {
         if (user->weight > highest)
         {
            best = user;
            highest = user->weight;
         }
      }
      user = user->next;
   }
   if (best == NULL)
      return 0;
   snprintf (buf, sizeof (buf), "%s: ", best->user);
   gtk_entry_set_text (GTK_ENTRY (t), buf);
   return 0;
}

void
history_add (struct history *his, char *text)
{
   if (his->lines[his->realpos])
      free (his->lines[his->realpos]);
   his->lines[his->realpos] = strdup (text);
   his->realpos++;
   if (his->realpos == HISTORY_SIZE)
      his->realpos = 0;
   his->pos = his->realpos;
}

void
history_free (struct history *his)
{
   int i;
   for (i = 0; i < HISTORY_SIZE; i++)
   {
      if (his->lines[i])
         free (his->lines[i]);
   }
}

void
history_insert_text (GtkWidget * entry, char *text)
{
   char newtext[3000];
   char *oldtext;
   int pos;

   oldtext = gtk_entry_get_text (GTK_ENTRY (entry));
   pos = gtk_editable_get_position ((GtkEditable *) entry);
   strcpy (newtext, oldtext);
   newtext[pos] = 0;
   strcat (newtext, text);
   strcat (newtext, &oldtext[pos]);
   gtk_entry_set_text (GTK_ENTRY (entry), newtext);
   gtk_entry_set_position (GTK_ENTRY (entry), pos + strlen (text));
}

void
history_function_key (GtkWidget * entry, int which)
{
   GSList *list = fkey_list;
   int i = 0;

   while (list)
   {
      char *macro = (char *) list->data;
      i++;
      if (i == which)
      {
         history_insert_text (entry, macro);
         return;
      }
      list = list->next;
   }
}

void
history_down (GtkWidget * widget, struct history *his)
{
   his->pos++;
   if (his->pos == HISTORY_SIZE)
      his->pos = 0;
   if (his->lines[his->pos])
   {
      gtk_entry_set_text (GTK_ENTRY (widget), his->lines[his->pos]);
   } else
   {
      if (his->pos != 0)
         his->pos--;
      else
         his->pos = (HISTORY_SIZE - 1);
   }
}

void
history_up (GtkWidget * widget, struct history *his)
{
   if (his->pos == 0)
      his->pos = (HISTORY_SIZE - 1);
   else
      his->pos--;
   if (his->lines[his->pos])
   {
      gtk_entry_set_text (GTK_ENTRY (widget), his->lines[his->pos]);
   } else
   {
      if (his->pos == (HISTORY_SIZE - 1))
         his->pos = 0;
      else
         his->pos++;
   }
}

/* handles PageUp/Down keys */
void
scroll_page (GtkWidget * inputgad, int up)
{
   int value, end;
   GtkAdjustment *adj;
   struct session *sess = find_session_from_inputgad (inputgad);

   if (sess)
   {
#ifdef USE_GNOME
      if (sess->zvt)
         adj = ((ZvtTerm *) sess->textgad)->adjustment;
      else
         adj = GTK_TEXT (sess->textgad)->vadj;
#else
      adj = GTK_TEXT (sess->textgad)->vadj;
#endif

      if (up)                   /* PageUp */
      {
         value = adj->value - (adj->page_size / 2);
         if (value < 0)
            value = 0;
      } else
      {                         /* PageDown */
         end = adj->upper - adj->lower - adj->page_size;
         value = adj->value + (adj->page_size / 2);
         if (value > end)
            value = end;
      }
      gtk_adjustment_set_value (adj, value);
   }
}

int
history_keypress (GtkWidget * widget, GdkEventKey * event, struct history *his)
{
   GtkEditable *editable;
   gint tmp_pos;

   editable = GTK_EDITABLE (widget);

   switch (event->keyval)
   {
   case GDK_space:
      replace_handle (widget);
      return 0;
   case GDK_F1:
      history_function_key (widget, 1);
      break;
   case GDK_F2:
      history_function_key (widget, 2);
      break;
   case GDK_F3:
      history_function_key (widget, 3);
      break;
   case GDK_F4:
      history_function_key (widget, 4);
      break;
   case GDK_F5:
      history_function_key (widget, 5);
      break;
   case GDK_F6:
      history_function_key (widget, 6);
      break;
   case GDK_F7:
      history_function_key (widget, 7);
      break;
   case GDK_F8:
      history_function_key (widget, 8);
      break;
   case GDK_F9:
      history_function_key (widget, 9);
      break;
   case GDK_F10:
      history_function_key (widget, 10);
      break;
   case GDK_Tab:
      if (tab_nick_comp (widget) == -1)
         return 0;
      else
         break;
   case GDK_Down:
      history_down (widget, his);
      break;

   case GDK_Up:
      history_up (widget, his);
      break;

   case GDK_p:                 /* History up */
      if (prefs.emacs_key_bindings)
         if (event->state & STATE_CTRL)
            history_up (widget, his);
      return 0;

   case GDK_n:                 /* History down */
      if (prefs.emacs_key_bindings)
         if (event->state & STATE_CTRL)
            history_down (widget, his);
      return 0;

   case GDK_Page_Down:
      if (event->state & STATE_SHIFT)
         nick_comp_chng (widget, 0);
      else
         scroll_page (widget, 0);
      break;

   case GDK_Page_Up:
      if (event->state & STATE_SHIFT)
         nick_comp_chng (widget, 1);
      else
         scroll_page (widget, 1);
      break;

      /*case GDK_Page_Down:
         nick_comp_chng(widget, 0); break;

         case GDK_Page_Up:
         nick_comp_chng(widget, 1); break; */

   case GDK_equal:
      if ((event->state & STATE_ALT) && main_window)
      {
         if (event->state & STATE_CTRL)
            gtk_notebook_set_page (GTK_NOTEBOOK (main_book), gtk_notebook_get_current_page (GTK_NOTEBOOK (main_book)) + 3);
         else
            gtk_notebook_next_page (GTK_NOTEBOOK (main_book));
      }
      return 0;
   case GDK_minus:
      if ((event->state & STATE_ALT) && main_window)
      {
         if (event->state & STATE_CTRL)
            gtk_notebook_set_page (GTK_NOTEBOOK (main_book), gtk_notebook_get_current_page (GTK_NOTEBOOK (main_book)) - 3);
         else
            gtk_notebook_prev_page (GTK_NOTEBOOK (main_book));
      }
      return 0;
   case GDK_1:
      if ((event->state & STATE_ALT) && main_window)
         gtk_notebook_set_page (GTK_NOTEBOOK (main_book), 0);
      return 0;
   case GDK_2:
      if ((event->state & STATE_ALT) && main_window)
         gtk_notebook_set_page (GTK_NOTEBOOK (main_book), 1);
      return 0;
   case GDK_3:
      if ((event->state & STATE_ALT) && main_window)
         gtk_notebook_set_page (GTK_NOTEBOOK (main_book), 2);
      return 0;
   case GDK_4:
      if ((event->state & STATE_ALT) && main_window)
         gtk_notebook_set_page (GTK_NOTEBOOK (main_book), 3);
      return 0;
   case GDK_5:
      if ((event->state & STATE_ALT) && main_window)
         gtk_notebook_set_page (GTK_NOTEBOOK (main_book), 4);
      return 0;
   case GDK_6:
      if ((event->state & STATE_ALT) && main_window)
         gtk_notebook_set_page (GTK_NOTEBOOK (main_book), 5);
      return 0;
   case GDK_7:
      if ((event->state & STATE_ALT) && main_window)
         gtk_notebook_set_page (GTK_NOTEBOOK (main_book), 6);
      return 0;
   case GDK_8:
      if ((event->state & STATE_ALT) && main_window)
         gtk_notebook_set_page (GTK_NOTEBOOK (main_book), 7);
      return 0;
   case GDK_9:
      if ((event->state & STATE_ALT) && main_window)
         gtk_notebook_set_page (GTK_NOTEBOOK (main_book), 8);
      return 0;
   case GDK_0:
      if ((event->state & STATE_ALT) && main_window)
         gtk_notebook_set_page (GTK_NOTEBOOK (main_book), 9);
      return 0;
   case GDK_k:                 /* Color */
      if (prefs.emacs_key_bindings)
         return 0;
      if (event->state & STATE_CTRL)
      {
         tmp_pos = editable->current_pos;
         gtk_editable_insert_text (editable, "\3", 1, &tmp_pos);
         editable->current_pos = tmp_pos;
         gtk_signal_emit_stop_by_name (GTK_OBJECT (widget), "key_press_event");
      }
      return 0;
   case GDK_b:                 /* bold */
      if (prefs.emacs_key_bindings)
         return 0;
      if (event->state & STATE_CTRL)
      {
         tmp_pos = editable->current_pos;
         gtk_editable_insert_text (editable, "\2", 1, &tmp_pos);
         editable->current_pos = tmp_pos;
         gtk_signal_emit_stop_by_name (GTK_OBJECT (widget), "key_press_event");
      }
      return 0;
      /* removed underline beceause ctrl-u is used to clear the textgadget */
/*      case GDK_u: Underline
   if(event->state & STATE_CTRL)
   {
   tmp_pos = editable->current_pos;
   gtk_editable_insert_text (editable, "\037", 1, &tmp_pos);
   editable->current_pos = tmp_pos;
   gtk_signal_emit_stop_by_name(GTK_OBJECT(widget), "key_press_event");
   }
   return 0; */
   case GDK_r:                 /* reverse */
      if (prefs.emacs_key_bindings)
         return 0;
      if (event->state & STATE_CTRL)
      {
         tmp_pos = editable->current_pos;
         gtk_editable_insert_text (editable, "\026", 1, &tmp_pos);
         editable->current_pos = tmp_pos;
         gtk_signal_emit_stop_by_name (GTK_OBJECT (widget), "key_press_event");
      }
      return 0;
   case GDK_c:                 /* Clear */
      if (prefs.emacs_key_bindings)
         return 0;
      if (event->state & STATE_CTRL)
      {
         tmp_pos = editable->current_pos;
         gtk_editable_insert_text (editable, "\017", 1, &tmp_pos);
         editable->current_pos = tmp_pos;
         gtk_signal_emit_stop_by_name (GTK_OBJECT (widget), "key_press_event");
      }
      return 0;

   default:
      return 0;
   }
   gtk_signal_emit_stop_by_name (GTK_OBJECT (widget), "key_press_event");
   return 1;
}
