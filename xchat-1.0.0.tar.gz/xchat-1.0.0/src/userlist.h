struct user
{
   struct user *next;
   char user[64];
   int weight;
   int op:1;
   int voice:1;
};
