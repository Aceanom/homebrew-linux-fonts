
#ifndef	PLUGIN_H
#define PLUGIN_H

#define	MODULE_IFACE_VER	2
#define TE_MAX_VAL 98
#define	XP_CALLBACK(x)	( (int (*) (void *, void *, void *, void *, void *, char) ) x )

#define	XP_USERCOMMAND	0
#define XP_PRIVMSG	1
#define XP_CHANACTION	2
#define XP_CHANMSG	3
#define XP_CHANGENICK	4
#define XP_JOIN		5
#define XP_CHANSETKEY	6
#define XP_CHANSETLIMIT	7
#define	XP_CHANOP	8
#define	XP_CHANVOICE	9
#define XP_CHANBAN	10
#define XP_CHANRMKEY	11
#define	XP_CHANRMLIMIT	12
#define	XP_CHANDEOP	13
#define	XP_CHANDEVOICE	14
#define	XP_CHANUNBAN	15
#define XP_INBOUND	16

#define XP_TE_JOIN       17
#define XP_TE_CHANACTION 18
#define XP_TE_CHANMSG   19
#define XP_TE_PRIVMSG   20
#define XP_TE_CHANGENICK 21
#define XP_TE_NEWTOPIC  22
#define XP_TE_TOPIC     23
#define XP_TE_KICK      24
#define XP_TE_PART      25
#define XP_TE_CHANDATE  26
#define XP_TE_TOPICDATE 27
#define XP_TE_QUIT      28
#define XP_TE_PINGREP   29
#define XP_TE_NOTICE    30
#define XP_TE_UJOIN     31
#define XP_TE_UCHANMSG  32
#define XP_TE_DPRIVMSG  33
#define XP_TE_UCHANGENICK 34
#define XP_TE_UKICK     35
#define XP_TE_UPART     36
#define XP_TE_CTCPSND   37
#define XP_TE_CTCPGEN   38
#define XP_TE_CTCPGENC  39
#define XP_TE_CHANSETKEY 40
#define XP_TE_CHANSETLIMIT 41
#define XP_TE_CHANOP    42
#define XP_TE_CHANVOICE 43
#define XP_TE_CHANBAN   44
#define XP_TE_CHANRMKEY 45
#define XP_TE_CHANRMLIMIT 46
#define XP_TE_CHANDEOP  47
#define XP_TE_CHANDEVOICE 48
#define XP_TE_CHANUNBAN 49
#define XP_TE_CHANMODEGEN 50
#define XP_TE_WHOIS1    51
#define XP_TE_WHOIS2    52
#define XP_TE_WHOIS3    53
#define XP_TE_WHOIS4    54
#define XP_TE_WHOIS4T   55
#define XP_TE_WHOIS5    56
#define XP_TE_WHOIS6    57
#define XP_TE_USERLIMIT 58
#define XP_TE_BANNED    59
#define XP_TE_INVITE    60
#define XP_TE_KEYWORD   61
#define XP_TE_MOTDSKIP  62
#define XP_TE_SERVTEXT  63
#define XP_TE_INVITED   64
#define XP_TE_USERSONCHAN 65
#define XP_TE_NICKCLASH 66
#define XP_TE_NICKFAIL  67
#define XP_TE_UKNHOST   68
#define XP_TE_CONNFAIL  69
#define XP_TE_CONNECT   70
#define XP_TE_CONNECTED 71
#define XP_TE_SCONNECT  72
#define XP_TE_DISCON    73
#define XP_TE_NODCC     74
#define XP_TE_DELNOTIFY 75
#define XP_TE_ADDNOTIFY 76
#define XP_TE_WINTYPE   77
#define XP_TE_CHANMODES 78
#define XP_TE_RAWMODES  79
#define XP_TE_KILL      80
#define XP_TE_DCCSTALL  81
#define XP_TE_DCCTOUT   82
#define XP_TE_DCCCHATF  83
#define XP_TE_DCCFILEERR 84
#define XP_TE_DCCRECVERR 85
#define XP_TE_DCCRECVCOMP 86
#define XP_TE_DCCCONFAIL 87
#define XP_TE_DCCCON    88
#define XP_TE_DCCSENDFAIL 89
#define XP_TE_DCCSENDCOMP 90
#define XP_TE_DCCOFFER  91
#define XP_TE_DCCABORT  92
#define XP_TE_DCCIVAL   93
#define XP_TE_DCCCHATREOFFER 94
#define XP_TE_DCCCHATOFFERING 95
#define XP_TE_DCCDRAWOFFER 96
#define XP_TE_DCCCHATOFFER 97
#define XP_TE_DCCRESUMEREQUEST 98
#define XP_TE_DCCSENDOFFER 99
#define XP_TE_DCCGENERICOFFER 100
#define XP_TE_NOTIFYONLINE 101
#define XP_TE_NOTIFYNUMBER 102
#define XP_TE_NOTIFYEMPTY  103
#define XP_TE_NOCHILD      104
#define XP_TE_ALREADYPROCESS 105
#define XP_TE_SERVERLOOKUP 106
#define XP_TE_SERVERCONNECTED 107
#define XP_TE_SERVERERROR  108
#define XP_TE_SERVERGENMESSAGE 109
#define XP_TE_FOUNDIP      110
#define XP_TE_DCCRENAME    111
#define XP_TE_CTCPSEND     112
#define XP_TE_MSGSEND      113
#define XP_TE_NOTICESEND   114
#define XP_TE_WALLOPS      115
#define XP_HIGHLIGHT       116

#define	NUM_XP	        117


#define	EMIT_SIGNAL(s, a, b, c, d, e, f) (fire_signal(s, a, b, c, d, e, f))
#define	XP_CALLNEXT(s, a, b, c, d, e, f)  if (s != NULL) return s(a, b, c, d, e, f); return 0;
#define XP_CALLNEXT_ANDSET(s, a, b, c, d, e, f) if (s != NULL) s(a, b, c, d, e, f); return 1;

extern int current_signal;

#ifdef USE_PLUGIN

struct module
{
   void *handle;
   char *name, *desc;
   struct module *next, *last;
};

struct module_cmd_set
{
   struct module *mod;
   struct commands *cmds;
   struct module_cmd_set *next, *last;
};

#endif

struct xp_signal
{
   int signal;
   int (**naddr) (void *, void *, void *, void *, void *, char);
   int (*callback) (void *, void *, void *, void *, void *, char);
#ifdef USE_PLUGIN
   struct module *mod;
#else
   void *padding;
#endif
   struct xp_signal *next, *last;
};

struct pevt_stage1
{
   int len;
   char *data;
   struct pevt_stage1 *next;
};

#ifndef	PLUGIN_C
extern int (*sighandler[NUM_XP]) (void *, void *, void *, void *, void *, char);
extern struct xp_signal *sigroots[0];
extern int fire_signal (int, void *, void *, void *, void *, void *, char);

#endif

#endif /* PLUGIN_H */
