
#define HISTORY_SIZE 100

struct history
{
   char *lines[HISTORY_SIZE];
   int pos;
   int realpos;
};


void history_add (struct history *his, char *text);
void history_free (struct history *his);
int history_keypress (GtkWidget * widget, GdkEventKey * event, struct history *his);
