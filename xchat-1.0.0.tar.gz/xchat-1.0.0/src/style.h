/* this file is being phased out! */

#define STARTON "\0034*\003*\0034*\017"
#define STARTOFF "\0033*\003*\0033*\017"

#define CHANNEL_MSG_FROM_USER "\0036<\017%s\0036>\003 %s\003\n"
#define CHANNEL_MSG_WITH_NICK "\0032<\002\003%d%s\002\0032>\003 %s\003\n"
#define CHANNEL_MSG "\0032<\017%s\0032>\003 %s\003\n"
#define CHANNEL_MSG_COLOR "<\003%d%s\003> %s\003\n"
