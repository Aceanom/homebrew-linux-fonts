void open_rawlog (server *serv);
