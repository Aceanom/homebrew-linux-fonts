void PrintTextRaw (void *xtbuf, unsigned char *text, int indent);
void pevent_dialog_show (void);
