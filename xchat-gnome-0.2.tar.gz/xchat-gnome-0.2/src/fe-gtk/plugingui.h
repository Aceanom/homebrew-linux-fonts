void plugingui_open (void);
void plugingui_load (void);
