void chanlist_opengui (server *serv);
