void banlist_opengui (session *sess);
