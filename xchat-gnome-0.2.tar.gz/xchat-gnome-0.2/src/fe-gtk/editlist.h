void editlist_gui_open (GSList * list, char *title, char *wmclass, char *file, char *help);
