void notify_gui_update (void);
void notify_opengui (void);
