void ascii_open (void);
