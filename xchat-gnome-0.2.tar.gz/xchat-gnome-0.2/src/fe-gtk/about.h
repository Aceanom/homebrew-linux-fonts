void menu_about (GtkWidget * wid, gpointer sess);
