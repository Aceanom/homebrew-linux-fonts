void url_autosave (void);
void url_opengui (void);
