void search_open (session * sess);
