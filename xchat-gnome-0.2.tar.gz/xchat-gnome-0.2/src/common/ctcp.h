#ifndef XCHAT_CTCP_H
#define XCHAT_CTCP_H

void ctcp_handle (session *sess, char *to, char *nick, char *msg, char *word[], char *word_eol[]);

#endif
