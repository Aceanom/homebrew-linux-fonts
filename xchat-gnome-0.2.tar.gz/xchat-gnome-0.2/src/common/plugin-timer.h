#ifndef XCHAT_PLUGIN_TIMER_H
#define XCHAT_PLUGIN_TIMER_H

int timer_plugin_init (xchat_plugin *plugin_handle, char **plugin_name,
				char **plugin_desc, char **plugin_version, char *arg);

#endif
