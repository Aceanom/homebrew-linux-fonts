#ifndef XCHAT_PROTO_H
#define XCHAT_PROTO_H

void proto_fill_her_up (server *serv);

#endif
