#ifndef __WINDOW_H__
#define __WINDOW_H__
#include "python.h"


extern PyTypeObject WindowType;
#endif
