function res = one()
res = 1;
end
