function res = one()
res = 1;
