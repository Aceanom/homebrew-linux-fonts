% ex04.m: script file
a = 1;
b = 2;
