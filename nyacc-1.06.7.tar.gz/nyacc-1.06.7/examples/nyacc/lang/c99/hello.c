
int printf(const char* fmt, ...);

int main(int argc, char *argv[]) {
  printf("Hello, world.\n");
}
