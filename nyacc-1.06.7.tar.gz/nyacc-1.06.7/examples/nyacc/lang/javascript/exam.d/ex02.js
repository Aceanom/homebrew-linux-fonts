var pt = { x:3, y:4 }
function norm(pt) { return sqrt(pt.x*pt.x + pt.y*pt.y); }
norm(pt)
