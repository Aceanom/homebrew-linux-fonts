var a = 1, b
function foo(x, y) {
  var v, w = 3;
  v = x + w;
  var t;
  t = y + 5;
  return sqrt(t + v);
}
var c = 2
a = foo(a,c)
a
