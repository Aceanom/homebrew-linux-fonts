var uid = 1; uid++ ;
//var uid = { v: { w: 1} }; uid.v.w++ ;
//var uid = { v: 1 }; uid.v++ ;
//var uid = [ 5, 1 ]; uid[0]++ ;
