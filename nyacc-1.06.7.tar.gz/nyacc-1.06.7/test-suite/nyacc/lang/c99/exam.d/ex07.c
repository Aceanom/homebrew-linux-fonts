int foo () {
  int r = 1;
  #include "ex07.i"
  return r;
} 
