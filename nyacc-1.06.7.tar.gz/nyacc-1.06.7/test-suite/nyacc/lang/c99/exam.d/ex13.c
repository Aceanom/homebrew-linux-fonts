#if defined ABC
#endif
#if defined ABC /* hello */
#endif
#if defined(ABC)
#endif
#if defined( ABC )
#endif
#if defined ( ABC )
#endif
#if defined ( ABC ) /* abc */
#endif
