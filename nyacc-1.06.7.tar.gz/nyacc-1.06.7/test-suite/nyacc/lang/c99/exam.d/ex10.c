#include <stdint.h>
int32_t x;
