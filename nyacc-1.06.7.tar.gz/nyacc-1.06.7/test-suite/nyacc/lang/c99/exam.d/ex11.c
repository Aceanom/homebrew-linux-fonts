/*Begin C Code*/
#if defined __HAB__
#define __HAB__
#endif
#define A 1

int a = A;
/*end C code*/
