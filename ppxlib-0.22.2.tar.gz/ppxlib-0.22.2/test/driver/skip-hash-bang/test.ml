#!ignored_line

let () = print_endline "OK"
