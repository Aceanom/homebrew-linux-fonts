module Make = Solver_core.Make
module Diagnostics = Diagnostics.Make
module Sat = Sat
module S = S
