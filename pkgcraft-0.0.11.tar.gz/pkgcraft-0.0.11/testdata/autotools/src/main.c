#include <config.h>
#include <stdio.h>

int main (void) {
	puts("executing binary for " PACKAGE_STRING);
	return 0;
}
