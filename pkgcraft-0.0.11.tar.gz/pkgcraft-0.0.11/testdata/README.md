Various test data for pkgcraft and its bindings.
