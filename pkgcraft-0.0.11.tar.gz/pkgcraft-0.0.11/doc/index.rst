pkgcraft documentation
======================

.. toctree::
    :maxdepth: 2


.. automodule:: pkgcraft


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
