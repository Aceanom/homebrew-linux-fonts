
#ifndef DIR_WINDOW_HANDLER_H
#define DIR_WINDOW_HANDLER_H

#include "common.h"

#define DW_CANCEL           100
#define DW_OK               101

char *dir_window_handler( int ops, char *cur_dir );

#endif
