/* Modified from cccd
 * http://www.hsp.de/~jst/cccd/ */
#ifndef CDDB_H
#define CDDB_H

#include "common.h"

int cddb_main( _main_data *main_data );

#endif
