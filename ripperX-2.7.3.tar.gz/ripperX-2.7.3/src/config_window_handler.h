
#ifndef CONFIG_WINDOW_HANDLER_H
#define CONFIG_WINDOW_HANDLER_H

#include "common.h"

void config_window_handler( int ops, _main_data *main_data );

#endif
