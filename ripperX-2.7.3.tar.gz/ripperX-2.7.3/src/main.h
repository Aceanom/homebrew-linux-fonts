
#ifndef MAIN_H
#define MAIN_H

#include "common.h"
#include <gtk/gtk.h>
#include <locale.h>
#include <string.h>

void ripperX_exit( GtkWidget *widget, gpointer callback_data );

#endif
