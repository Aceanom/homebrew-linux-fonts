
#ifndef INTERFACE_COMMON_H
#define INTERFACE_COMMON_H

#define WIDGET_CREATE       0
#define WIDGET_DESTROY      1
#define WIDGET_UPDATE       2
#define CLEAR_ENTRIES		3

#endif
