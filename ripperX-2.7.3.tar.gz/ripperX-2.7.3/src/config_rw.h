
#ifndef CONFIG_RW_H
#define CONFIG_RW_H

#include "common.h"

void read_config( void );
void write_config( void );

#endif
