class Strptime
  VERSION = "0.2.5"
end
