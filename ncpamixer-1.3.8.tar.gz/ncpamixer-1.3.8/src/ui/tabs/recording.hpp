#ifndef RECORDING_HPP_
#define RECORDING_HPP_

#include "../tab.hpp"

class Recording : public Tab
{
public:
    Recording();
    ~Recording() override = default;
};

#endif // PLAYBACK_HPP_
