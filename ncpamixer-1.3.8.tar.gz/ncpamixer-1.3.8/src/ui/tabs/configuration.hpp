#ifndef CONFIGURATION_HPP_
#define CONFIGURATION_HPP_

#include "../tab.hpp"

class Configuration : public Tab
{
public:
    Configuration();
    ~Configuration() override = default;

    // void draw();
};

#endif // PLAYBACK_HPP_
