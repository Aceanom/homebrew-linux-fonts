#ifndef INPUT_HPP_
#define INPUT_HPP_

#include "../tab.hpp"

class Input : public Tab
{
public:
    Input();
    ~Input() override = default;
};

#endif // PLAYBACK_HPP_
