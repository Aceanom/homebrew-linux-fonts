#ifndef PLAYBACK_HPP_
#define PLAYBACK_HPP_

#include "../tab.hpp"

class Playback : public Tab
{
public:
    Playback();
    ~Playback() override = default;
};

#endif // PLAYBACK_HPP_
