#ifndef OUTPUT_HPP_
#define OUTPUT_HPP_

#include "../tab.hpp"

class Output : public Tab
{
public:
    Output();
    ~Output() override = default;
};

#endif // PLAYBACK_HPP_
