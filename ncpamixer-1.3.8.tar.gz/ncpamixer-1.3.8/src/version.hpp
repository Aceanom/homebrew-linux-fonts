#ifndef VERSION_HPP_
#define VERSION_HPP_

extern const char GIT_VERSION[];
extern const char BUILD_TYPE[];
extern const char BUILD_DATE[];

const char FALLBACK_VERSION[] = "1.3";

#endif // VERSION_HPP_
