#ifndef PA_PORT_
#define PA_PORT_
#include "pa_object_attribute.hpp"

class PaPort : public PaObjectAttribute
{
public:
    int available;
};
#endif // PA_PORT_
