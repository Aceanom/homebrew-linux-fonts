## yesod-core

This is the main package for Yesod, providing all core functionality on which
other packages can be built. It provides dispatch, handler functions, widgets,
etc.

Yesod is well documented on [its website](http://www.yesodweb.com/).
